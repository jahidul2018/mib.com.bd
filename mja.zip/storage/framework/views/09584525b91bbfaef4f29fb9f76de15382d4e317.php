
<div class="list-group">
  <?php $__currentLoopData = App\Models\Category::orderBy('name', 'asc')->where('parent_id', NULL)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="#main-<?php echo e($parent->id); ?>" class="list-group-item list-group-item-action" data-toggle="collapse">
      <img src="<?php echo asset('images/categories/'.$parent->image); ?>" width="50">
      <?php echo e($parent->name); ?>

    </a>
    <div class="collapse
      <?php if(Route::is('categories.show')): ?>
        <?php if(App\Models\Category::ParentOrNotCategory($parent->id, $category->id)): ?>
          show
        <?php endif; ?>
      <?php endif; ?>
    " id="main-<?php echo e($parent->id); ?>">
      <div class="child-rows">
        <?php $__currentLoopData = App\Models\Category::orderBy('name', 'asc')->where('parent_id', $parent->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo route('categories.show', $child->id); ?>" class="list-group-item list-group-item-action
            <?php if(Route::is('categories.show')): ?>
              <?php if($child->id == $category->id): ?>
                active
              <?php endif; ?>
            <?php endif; ?>
            ">
            <img src="<?php echo asset('images/categories/'.$child->image); ?>" width="30">
            <?php echo e($child->name); ?>

          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>


    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
