<?php $__env->startSection('content'); ?>
  <!-- Start Sidebar + Content -->
  <div class='container margin-top-20'>
    <div class="row">
      <div class="col-md-4">
        <?php echo $__env->make('frontend.partials.product-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>

      <div class="col-md-8">
        <div class="widget">
          <h3>All Products</h3>
          <?php echo $__env->make('frontend.pages.product.partials.all_products', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="widget">

        </div>
      </div>


    </div>
  </div>

  <!-- End Sidebar + Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>